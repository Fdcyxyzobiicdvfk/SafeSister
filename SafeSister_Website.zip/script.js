function scanMessage() {
  const input = document.getElementById("messageInput").value.toLowerCase();
  const result = document.getElementById("result");

  const scamWords = ["click here", "send nudes", "free gift", "airtime", "win", "verify"];
  const scamLinks = ["bit.ly", "tinyurl", "cashgift", "dropbox"];

  const isScam = scamWords.some(word => input.includes(word)) ||
                 scamLinks.some(link => input.includes(link));

  if (isScam) {
    result.innerHTML = "⚠️ Danger: This message may be a scam!";
    result.style.background = "#f8d7da";
  } else {
    result.innerHTML = "✅ Safe: No threats detected.";
    result.style.background = "#d4edda";
  }
}
